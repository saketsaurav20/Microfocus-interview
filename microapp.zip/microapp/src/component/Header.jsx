import React, { useCallback, useEffect, useState } from 'react'
import '../App.css';
import { Link } from 'react-router-dom';
import Digitalclock from './Digitalclock';
import Footer from './Footer';

function Header() {

    const [position, setPosition] = useState("center");

    const handleChange = (e) => {
        console.log(e.target.value);
        setPosition(e.target.value);
    }
    const escFunction = useCallback((event) => {
        if (event.key === "Escape") {
            const card = document.getElementsByClassName('card_container');
            card[0].style.display = 'none'
        }
        if (event.key === "Enter") {
            const card = document.getElementsByClassName('card_container');
            card[0].style.display = 'flex';
        }
    }, []);

    useEffect(() => {
        document.addEventListener("keydown", escFunction, false);

        return () => {
            document.removeEventListener("keydown", escFunction, false);
        };
    }, []);
    return (
        <>
            <div className='nav_container'>
                <ul className='nav_item'>
                    <li>Position:</li>
                    <li>
                        <input
                            id="center_div"
                            type="radio"
                            name='position'
                            value={"center"}
                            onChange={handleChange}
                            checked={position === "center"}
                        />
                        <label>Center</label>
                    </li>
                    <li> <input
                        id="lower_div"
                        type="radio"
                        name='position'
                        value={"lower"}
                        onChange={handleChange}
                        checked={position === "lower"}
                    /><label>Lower Right</label>
                    </li>
                    <li>Press Esc to hide window , Enter to show it again</li>
                    <li>
                        <Digitalclock />
                    </li>
                </ul>
            </div>
            <div className={`card_container ${position === "center" ? "card_center" : ""}`}>
                <div className={`card ${position === "lower" ? "card_lower" : ""}`}>
                    <div className="container">
                        <h4><b>Change the position</b></h4>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Header