import React from 'react'
import { useNavigate } from 'react-router-dom';
import '../App.css';

function About() {
    const navigate = useNavigate();
    return (
        <div className='about_container'>
            <div>Page 2</div>
            <div className='about_body'>
                <div className='about_heading'>ABOUT ME</div>
                <ul className='about_me'>
                    <li> I am a Frontend Developer Having 2 Years of Experience in Reactjs, HTML5, CSS3, Redux, Jest. </li>
                    <li>I am aspiring to become FullStack Developer and I am self training myself on Nodejs and GraphQl.</li>
                    <li>I have worked for largest Healthcare sector company i.e Cardinal Health on their med-pharma e-commerce platform.</li>
                    <li>Recently I am working on Internal project which is for Accenture Leaderships</li>
                    <li>My hobby is watching anime and reading manga.</li>
                </ul>
            </div>
            <div><button type='button' onClick={() => { navigate('/') }}>{'<< Back'}</button></div>
        </div>
    )
}

export default About