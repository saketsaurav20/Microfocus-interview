import React from 'react'
import { Link } from 'react-router-dom';
import '../App.css';

function Footer() {
    return (
        <div className='footer'>
            <Link to='/about'>Go To Page 2</Link>
        </div>
    )
}

export default Footer