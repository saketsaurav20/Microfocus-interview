import React, { useEffect, useState } from 'react'

function Digitalclock() {
    const [clockState, setClockState] = useState();

    useEffect(() => {
        const timer = setInterval(() => {
            const date = new Date();
            setClockState(date.toLocaleTimeString());
        }, 1000);
        return () => {
            clearInterval(timer);
        }
    }, [])
    return (
        <div>{clockState}</div>
    )
}

export default Digitalclock