import './App.css';
import Footer from './component/Footer';
import Header from './component/Header';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import About from './component/About';
function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path='/' element={<Header />} />
          <Route path='/about' element={<About />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
